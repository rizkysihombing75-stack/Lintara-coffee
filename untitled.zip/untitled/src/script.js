// Navbar aktif
const navLinks = document.querySelectorAll("nav ul li a");
navLinks.forEach(link => {
  link.addEventListener("click", () => {
    navLinks.forEach(l => l.classList.remove("active"));
    link.classList.add("active");
  });
});

// Produk slide-in + modal
const produkItems = document.querySelectorAll('.slide-in-left, .slide-in-right');
const produkObserver = new IntersectionObserver((entries, observer) => {
  entries.forEach(entry => {
    if(entry.isIntersecting){
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.2 });

produkItems.forEach(item => {
  produkObserver.observe(item);
  item.addEventListener('click', () => {
    const modal = document.getElementById('modal');
    modal.style.display = 'flex';
    document.getElementById('modalTitle').textContent = item.querySelector('h3').textContent;
    document.getElementById('modalContent').textContent = item.dataset.proses;
  });
});

// Tutup modal produk
document.getElementById('closeModal').addEventListener('click', () => {
  document.getElementById('modal').style.display = 'none';
});

// Galeri fade-in + modal
const galeriItems = document.querySelectorAll('.galeri-item');
const galeriObserver = new IntersectionObserver((entries, observer) => {
  entries.forEach(entry => {
    if(entry.isIntersecting){
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.2 });

galeriItems.forEach(item => {
  galeriObserver.observe(item);
  item.addEventListener('click', () => {
    const modalGaleri = document.getElementById('modalGaleri');
    const modalImg = document.getElementById('modalGaleriImg');
    modalGaleri.style.display = 'flex';
    modalImg.src = item.dataset.src;
  });
});

// Tutup modal galeri
document.getElementById('closeGaleri').addEventListener('click', () => {
  document.getElementById('modalGaleri').style.display = 'none';
});
window.addEventListener('click', e => {
  const modalGaleri = document.getElementById('modalGaleri');
  if(e.target == modalGaleri){
    modalGaleri.style.display = 'none';
  }
});
